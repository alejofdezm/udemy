<?php  // Moodle configuration file

unset($CFG);
global $CFG;
$CFG = new stdClass();

$CFG->dbtype    = 'mariadb';
$CFG->dblibrary = 'native';
$CFG->dbhost    = 'serverdb';
$CFG->dbname    = 'udemycurso';
$CFG->dbuser    = 'root';
$CFG->dbpass    = 'Nuevo123*';
$CFG->prefix    = 'mdl_';
$CFG->dboptions = array (
  'dbpersist' => 0,
  'dbport' => '',
  'dbsocket' => '',
  'dbcollation' => 'utf8mb4_general_ci',
);
$CFG->wwwroot   = 'http://'.$_SERVER['HTTP_HOST'];
//$CFG->wwwroot   = 'http://127.0.0.1:8082';
$CFG->dataroot  = '/var/www/html/moodledata';
$CFG->admin     = 'admin';
  
$CFG->directorypermissions = 0777;

require_once(__DIR__ . '/lib/setup.php');

// There is no php closing tag in this file,
// it is intentional because it prevents trailing whitespace problems!
